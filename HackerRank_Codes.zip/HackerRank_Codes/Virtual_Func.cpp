#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;

class Person
{
public:

	string name;
	int age;
	//static int cur_id;


	virtual void getdata()
	{

	}

	virtual void putdata()
	{

	}

};

//int Person::cur_id;

class Professor : public Person
{
	int publication;
	int id_p;
	static int cur_id_p;
public:

	Professor()
	{
		cur_id_p++;
		id_p = cur_id_p;
	}

	void getdata()
	{
		cin >> name >> age >> publication;
	}

	void putdata()
	{
		cout << name << " " << age << " " << publication << " " << id_p << endl;
	}
};

int Professor::cur_id_p;

class Student : public Person
{
	int marks[6];
	int id_s;
	static int cur_id_s;
public:

	Student()
	{
		cur_id_s++;
		id_s = cur_id_s;
	}

	void getdata()
	{
		cin >> name >> age;
		for (int i = 0; i < 6; i++)
		{
			cin >> marks[i];
		}
	}

	void putdata()
	{
		int sum = 0;
		for (int i = 0; i < 6; i++)
		{
			sum += marks[i];
		}
		cout << name << " " << age << " " << sum << " " << id_s << endl;
	}
};

int Student::cur_id_s;

int main() {

	int n, val;
	cin >> n; //The number of objects that is going to be created.
	Person* per[4];

	for (int i = 0; i < n; i++) {

		cin >> val;
		if (val == 1) {
			// If val is 1 current object is of type Professor
			per[i] = new Professor;

		}
		else per[i] = new Student; // Else the current object is of type Student

		per[i]->getdata(); // Get the data from the user.

	}

	for (int i = 0; i < n; i++)
		per[i]->putdata(); // Print the required output for each object.

	return 0;

}
